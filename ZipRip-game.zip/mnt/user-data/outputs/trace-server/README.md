# trace-server

Flask app that serves the single-file `trace.html` and provides a REST API
for cross-user leaderboards, aggregates, and insights.

## Quick start

```bash
pip install -r requirements.txt
python app.py            # SQLite (default), listens on :5000
```

Then open <http://localhost:5000>.

For Postgres:

```bash
pip install psycopg2-binary
DATABASE_URL='postgresql://user:pass@host/dbname' python app.py
```

## File layout

- `app.py` — Flask routes
- `db.py` — thin DAL (SQLite / Postgres)
- `schema.sql` — canonical schema (CREATE TABLE IF NOT EXISTS + indices)
- `trace.html` — the client; copy of `../trace.html`
- `requirements.txt` — Flask, optional psycopg2-binary

## API

### Meta
- `GET /api/health` — backend + current ToS version
- `GET /api/tos` — placeholder ToS text + FAQ items + version
- `GET /api/summary` — counts across all stored attempts

### Users (phase 1)
- `POST /api/users` — create / update profile, accept ToS
- `GET /api/users/<uid>` — fetch profile
- `DELETE /api/users/<uid>` — GDPR-style erasure (user + their attempts)

### Attempts
- `POST /api/attempts` — log one attempt (rejected unless the user has
  accepted the current ToS version)
- `GET /api/attempts?user_id=&limit=` — list attempts

### Leaderboards (phase 2)
- `GET /api/daily[?date=YYYY-MM-DD]` — today's daily puzzle metadata
- `GET /api/leaderboard/puzzle?seed=&size=&difficulty=` — top times for one puzzle
- `GET /api/leaderboard/daily[?date=YYYY-MM-DD]` — top times for today's daily

### Aggregates + insights (phase 3 + 4)
- `GET /api/aggregates[?size=&difficulty=]` — global medians / percentiles
- `GET /api/insights/personal/<uid>` — one user's own data, sliced
- `GET /api/insights?slice_by=&metric=&size=&difficulty=&min_samples=&verified_env_only=`
  — THE phase-4 endpoint. `slice_by` must be in the allowed set
  (lifestyle + environmental columns + derived `hour_of_day` / `day_of_week`).
  Lifestyle slices filter to users with `share_lifestyle_in_aggregate=1`.
  Groups below `min_samples` (default 20) are suppressed.

## Privacy enforcement

Defence in depth — both the client UI and `db.py` enforce the consent
flags. The DAL JOINs `users` and applies a WHERE clause on the relevant
flag (`is_public` for leaderboards, `share_lifestyle_in_aggregate` for
lifestyle slicer queries, etc.) so a misbehaving or stale client can't
bypass them.

The `/api/attempts` POST endpoint refuses requests from any `user_id` that
either doesn't exist OR has an outdated `tos_version` — so the server is
the source of truth on consent, not the client.

## Schema migrations

`db.py:init_schema()` runs `schema.sql` (with `CREATE TABLE IF NOT EXISTS`
everywhere) plus a handful of safe `ALTER TABLE` calls wrapped in
try/except — so existing v1 databases pick up the new v2 columns
(`is_public`, `env_verified`, `tos_version`) on next server start without
manual intervention.

## Known limitations

- Geolocation requires HTTPS or `localhost` in modern browsers; on
  `file://` the Detect-location button will fail silently.
- The daily puzzle rotation lives in `db.py:DAILY_ROTATION` (Mon=tricky/6,
  Tue=knotty/6, etc.). Edit there to tune the weekly difficulty curve.
- `min_samples` defaults to 20 for privacy; in a fresh install with little
  data, most insight slices will return empty until you accumulate enough.
  The slicer's dropdown includes `1+ (debug)` so you can verify queries
  work with low data.
- The 8×8 Fiendish puzzle takes 2–3 s to generate on first load.
